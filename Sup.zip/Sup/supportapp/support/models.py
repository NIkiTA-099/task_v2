from django.db import models
from django.contrib.auth.models import User


class Support(models.Model):
    autor = models.CharField(max_length= 50)
    title = models.CharField(max_length= 50)
    description = models.CharField(max_length= 300)
    date = models.DateTimeField(auto_now_add=True)
    done = models.BooleanField(default=False)
    user = models.ForeignKey(User, verbose_name="Пользователь", default=1, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class Answer(models.Model):
    support = models.ForeignKey(Support, on_delete= models.CASCADE)
    text_answer = models.CharField(max_length= 500)
    date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.text_answer


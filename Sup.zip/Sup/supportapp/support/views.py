from django.db.models.signals import pre_save
from django.dispatch import receiver
from rest_framework import generics, viewsets
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from django.contrib.auth.models import User
from .permissions import IsAdminOrReadOnly, IsOwnerOrReadOnly
from .serializers import SupportSerializer, AnswerSerializer
from .models import *

class SupportAPIListPagination(PageNumberPagination):
    page_size = 2
    page_size_query_param = 'page_size'
    max_page_size = 10

class SupportAPIList(generics.ListCreateAPIView):
    queryset = Support.objects.all()
    serializer_class = SupportSerializer
    permission_classes = (IsAuthenticatedOrReadOnly, )
    pagination_class = SupportAPIListPagination


class SupportAPIUpdate(generics.RetrieveUpdateAPIView):
    queryset = Support.objects.all()
    serializer_class = SupportSerializer
    permission_classes = (IsOwnerOrReadOnly, )

class SupportAPIDestroy(generics.RetrieveDestroyAPIView):
    queryset = Support.objects.all()
    serializer_class = SupportSerializer
    permission_classes = (IsAdminOrReadOnly, )


class AnswerAPIList(generics.ListCreateAPIView, ):
    queryset = Answer.objects.all()
    serializer_class = AnswerSerializer
    permission_classes = (IsAdminOrReadOnly,)


from django.test import TestCase
from support.models import Support
from django.contrib.auth.models import User

class ModelsTestCase(TestCase):
    def test_post(self):
        post1 = User.objects.create_user('root','nik@gmai.com','123123')
        post1.save()
        post = Support.objects.create(autor = "Nikita")
        post.title = 'Laptop'
        post.description = 'Сломал ноут'
        post.pk
        self.assertEqual(post.pk, 1)